--Q1--

use Database1;

select* from [dbo].[Sales_Data$];

select State , count(OrderID) as TotalOrders,sum(Quantity) as TotalQuantity,sum(NetSales) as TotalSales,sum(Profit) as TotalProfit,sum(NetSales)/ count(distinct OrderID) as AverageOrderValue
from[dbo].[Sales_Data$]
where OrderStatus = 'Completed' group by State
Having sum (NetSales) > 1000000 order by TotalSales desc;




--Q2--

with CustomerSales as
(
select CustomerID,CustomerName,sum(NetSales) as TotalSales
from[dbo].[Sales_Data$] where OrderStatus = 'Completed' group by CustomerID,CustomerName
)
select top 5 CustomerID,CustomerName ,TotalSales from CustomerSales order by TotalSales desc;



--Q3--
with stateSales as 
( select State,
         sum(NetSales) as TotalSales from [dbo].[Sales_Data$] where OrderStatus = 'Completed' group by State)
         select state,TotalSales,RANK() over (order by TotalSales desc) as SalesRank from stateSales order by SalesRank
         